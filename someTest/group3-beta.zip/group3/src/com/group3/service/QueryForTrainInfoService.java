package com.group3.service;

import org.springframework.stereotype.Service;

import com.group3.po.Train;

@Service
public interface QueryForTrainInfoService {
	public Train queryForTrainInfo(Train train);
}
