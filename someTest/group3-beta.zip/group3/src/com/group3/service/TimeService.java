package com.group3.service;

import com.group3.po.Time;

public interface TimeService {

	public Time queryArvAndLvTime(int trainId, int stationId);
}
