package com.group3.service;

import com.group3.po.Station;

public interface QueryForStationService {
	public Station queryForStation(int id);
}
