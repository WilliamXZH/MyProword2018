package com.group3.vo;

public class StationVO {

	private Boolean isContained;
	private Integer id;
	private String name;

	private Integer trainId;
	private Integer stationId;
	private String arvTime;
	private String lvTime;

	public StationVO() {
		super();
	}

	public StationVO(Integer id, String name, Integer trainId, Integer stationId, String arvTime, String lvTime) {
		super();
		this.id = id;
		this.name = name;
		this.trainId = trainId;
		this.stationId = stationId;
		this.arvTime = arvTime;
		this.lvTime = lvTime;
	}

	public Boolean getIsContained() {
		return isContained;
	}

	public void setIsContained(Boolean isContained) {
		this.isContained = isContained;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getTrainId() {
		return trainId;
	}

	public void setTrainId(Integer trainId) {
		this.trainId = trainId;
	}

	public Integer getStationId() {
		return stationId;
	}

	public void setStationId(Integer stationId) {
		this.stationId = stationId;
	}

	public String getArvTime() {
		return arvTime;
	}

	public void setArvTime(String arvTime) {
		this.arvTime = arvTime;
	}

	public String getLvTime() {
		return lvTime;
	}

	public void setLvTime(String lvTime) {
		this.lvTime = lvTime;
	}

	@Override
	public String toString() {
		return "StationVO [isContained=" + isContained + ", id=" + id + ", name=" + name + ", trainId=" + trainId
				+ ", stationId=" + stationId + ", arvTime=" + arvTime + ", lvTime=" + lvTime + "]";
	}
}
