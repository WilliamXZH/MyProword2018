package com.group3.util.smtp;

public class SMTPSender {

	public String send(String recipient,String code){
		String result = null;
		
		
		return result;
	}
	
}
