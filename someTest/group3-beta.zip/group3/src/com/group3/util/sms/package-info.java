@javax.xml.bind.annotation.XmlSchema(namespace = "http://106.ihuyi.cn/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.group3.util.sms;
