package com.group3.po;

public class Seat {

	private Integer id;
	private Integer carriageId;
	private String num;
	private Integer status;
	public Seat() {
		super();
	}
	public Seat(Integer id, Integer carriageId, String num, Integer status) {
		super();
		this.id = id;
		this.carriageId = carriageId;
		this.num = num;
		this.status = status;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCarriageId() {
		return carriageId;
	}

	public void setCarriageId(Integer carriageId) {
		this.carriageId = carriageId;
	}

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Seat [id=" + id + ", carriageId=" + carriageId + ", num=" + num + ", status=" + status
				+ "]";
	}
	
}
