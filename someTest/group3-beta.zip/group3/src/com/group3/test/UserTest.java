package com.group3.test;

import java.util.Random;

import org.junit.Test;

public class UserTest {
	
	@Test
	public void codeTest(){
		for(int i=0;i<99;i++){
			String code=new Integer(new Random().nextInt(11)).toString();
			if(code.length()>=2)System.out.print(code+"\t");
			//if(i%10==9)System.out.println();
		}
	}
}
