package com.group3.mapper;

import java.util.List;

import com.group3.po.Agency;

public interface AgencyMapper {
	
	public List<Agency> agencySelect(String address);

}
